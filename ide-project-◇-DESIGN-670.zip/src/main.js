// Welcome to YOU–N–I–VERSE Studio
console.log("Hello from the Indyverse!");

function createUniverse() {
  return {
    name: "My Universe",
    stars: 1000,
    planets: 42
  };
}

const myUniverse = createUniverse();
console.log("Created:", myUniverse);