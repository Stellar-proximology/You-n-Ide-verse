import { SettingsPanel } from '../SettingsPanel';

export default function SettingsPanelExample() {
  return <SettingsPanel />;
}
