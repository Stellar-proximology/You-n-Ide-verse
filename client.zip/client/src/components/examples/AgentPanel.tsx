import { AgentPanel } from '../AgentPanel';

export default function AgentPanelExample() {
  return <AgentPanel />;
}
