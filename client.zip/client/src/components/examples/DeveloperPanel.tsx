import { DeveloperPanel } from '../DeveloperPanel';

export default function DeveloperPanelExample() {
  return <DeveloperPanel />;
}
