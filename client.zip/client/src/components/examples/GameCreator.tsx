import { GameCreator } from '../GameCreator';

export default function GameCreatorExample() {
  return <GameCreator />;
}
