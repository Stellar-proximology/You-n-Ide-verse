import { PlayerPanel } from '../PlayerPanel';

export default function PlayerPanelExample() {
  return <PlayerPanel />;
}
