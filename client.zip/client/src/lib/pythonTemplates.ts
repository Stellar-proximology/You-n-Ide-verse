import { type FileNode } from './fileSystem';

export interface PythonTemplate {
  id: string;
  title: string;
  description: string;
  tags: string[];
  files: FileNode[];
}

export const PYTHON_TEMPLATES: PythonTemplate[] = [
  {
    id: 'python-guess-number',
    title: 'Number Guessing Game',
    description: 'Simple number guessing game in Python',
    tags: ['Python', 'Game', 'Beginner'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `import random

print("=== Number Guessing Game ===")
print("I'm thinking of a number between 1 and 100!")

number = random.randint(1, 100)
attempts = 0
max_attempts = 10

while attempts < max_attempts:
    try:
        guess = int(input(f"\\nAttempt {attempts + 1}/{max_attempts} - Enter your guess: "))
        attempts += 1
        
        if guess < number:
            print("Too low! Try a higher number.")
        elif guess > number:
            print("Too high! Try a lower number.")
        else:
            print(f"\\n🎉 Congratulations! You guessed it in {attempts} attempts!")
            break
    except ValueError:
        print("Please enter a valid number!")

if attempts == max_attempts and guess != number:
    print(f"\\nGame Over! The number was {number}. Better luck next time!")
`
      }
    ]
  },
  {
    id: 'python-calculator',
    title: 'Calculator',
    description: 'Simple calculator with basic operations',
    tags: ['Python', 'Utility', 'Beginner'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `print("=== Python Calculator ===")
print("Operations: + (add), - (subtract), * (multiply), / (divide)")
print("Type 'quit' to exit\\n")

while True:
    operation = input("Enter operation (+, -, *, /) or 'quit': ")
    
    if operation.lower() == 'quit':
        print("Thanks for using the calculator!")
        break
    
    if operation not in ['+', '-', '*', '/']:
        print("Invalid operation! Please use +, -, *, or /")
        continue
    
    try:
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))
        
        if operation == '+':
            result = num1 + num2
        elif operation == '-':
            result = num1 - num2
        elif operation == '*':
            result = num1 * num2
        elif operation == '/':
            if num2 == 0:
                print("Error: Cannot divide by zero!")
                continue
            result = num1 / num2
        
        print(f"\\nResult: {num1} {operation} {num2} = {result}\\n")
    except ValueError:
        print("Error: Please enter valid numbers!\\n")
`
      }
    ]
  },
  {
    id: 'python-todo-list',
    title: 'Todo List',
    description: 'Simple command-line todo list manager',
    tags: ['Python', 'Productivity', 'Beginner'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `todos = []

def show_menu():
    print("\\n=== Todo List Manager ===")
    print("1. View todos")
    print("2. Add todo")
    print("3. Complete todo")
    print("4. Delete todo")
    print("5. Exit")

def view_todos():
    if not todos:
        print("\\nNo todos yet!")
    else:
        print("\\nYour todos:")
        for i, todo in enumerate(todos, 1):
            status = "✓" if todo['done'] else "○"
            print(f"{i}. [{status}] {todo['text']}")

def add_todo():
    text = input("\\nEnter todo: ")
    todos.append({'text': text, 'done': False})
    print(f"Added: {text}")

def complete_todo():
    view_todos()
    if todos:
        try:
            index = int(input("\\nEnter todo number to complete: ")) - 1
            if 0 <= index < len(todos):
                todos[index]['done'] = True
                print(f"Completed: {todos[index]['text']}")
            else:
                print("Invalid todo number!")
        except ValueError:
            print("Please enter a valid number!")

def delete_todo():
    view_todos()
    if todos:
        try:
            index = int(input("\\nEnter todo number to delete: ")) - 1
            if 0 <= index < len(todos):
                deleted = todos.pop(index)
                print(f"Deleted: {deleted['text']}")
            else:
                print("Invalid todo number!")
        except ValueError:
            print("Please enter a valid number!")

print("Welcome to Todo List Manager!")

while True:
    show_menu()
    choice = input("\\nChoose an option (1-5): ")
    
    if choice == '1':
        view_todos()
    elif choice == '2':
        add_todo()
    elif choice == '3':
        complete_todo()
    elif choice == '4':
        delete_todo()
    elif choice == '5':
        print("\\nGoodbye!")
        break
    else:
        print("Invalid choice! Please choose 1-5.")
`
      }
    ]
  },
  {
    id: 'python-pattern-printer',
    title: 'Pattern Printer',
    description: 'Create cool ASCII art patterns',
    tags: ['Python', 'Art', 'Beginner'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `def print_triangle(size):
    print("\\nTriangle Pattern:")
    for i in range(1, size + 1):
        print('* ' * i)

def print_pyramid(size):
    print("\\nPyramid Pattern:")
    for i in range(1, size + 1):
        spaces = ' ' * (size - i)
        stars = '* ' * i
        print(spaces + stars)

def print_diamond(size):
    print("\\nDiamond Pattern:")
    # Upper half
    for i in range(1, size + 1):
        spaces = ' ' * (size - i)
        stars = '* ' * i
        print(spaces + stars)
    # Lower half
    for i in range(size - 1, 0, -1):
        spaces = ' ' * (size - i)
        stars = '* ' * i
        print(spaces + stars)

def print_square(size):
    print("\\nSquare Pattern:")
    for i in range(size):
        if i == 0 or i == size - 1:
            print('* ' * size)
        else:
            print('* ' + '  ' * (size - 2) + '* ')

print("=== ASCII Pattern Printer ===")
print("1. Triangle")
print("2. Pyramid")
print("3. Diamond")
print("4. Square")
print("5. All patterns")

choice = input("\\nChoose a pattern (1-5): ")
size = int(input("Enter pattern size (3-10): "))

if size < 3 or size > 10:
    print("Size must be between 3 and 10!")
else:
    if choice == '1':
        print_triangle(size)
    elif choice == '2':
        print_pyramid(size)
    elif choice == '3':
        print_diamond(size)
    elif choice == '4':
        print_square(size)
    elif choice == '5':
        print_triangle(size)
        print_pyramid(size)
        print_diamond(size)
        print_square(size)
    else:
        print("Invalid choice!")
`
      }
    ]
  },
  {
    id: 'python-fizzbuzz',
    title: 'FizzBuzz',
    description: 'Classic FizzBuzz programming challenge',
    tags: ['Python', 'Challenge', 'Beginner'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `print("=== FizzBuzz Challenge ===")
print("Counting from 1 to 100:\\n")

for i in range(1, 101):
    if i % 15 == 0:
        print(f"{i}: FizzBuzz")
    elif i % 3 == 0:
        print(f"{i}: Fizz")
    elif i % 5 == 0:
        print(f"{i}: Buzz")
    else:
        print(f"{i}: {i}")

print("\\n✓ FizzBuzz complete!")
print("\\nRules:")
print("- Numbers divisible by 3: Fizz")
print("- Numbers divisible by 5: Buzz")
print("- Numbers divisible by both 3 and 5: FizzBuzz")
`
      }
    ]
  },
  {
    id: 'python-word-counter',
    title: 'Word Counter',
    description: 'Count words and characters in text',
    tags: ['Python', 'Utility', 'Intermediate'],
    files: [
      {
        name: 'main.py',
        type: 'file',
        path: 'main.py',
        content: `def analyze_text(text):
    # Remove leading/trailing whitespace
    text = text.strip()
    
    # Count characters (including spaces)
    char_count = len(text)
    
    # Count characters (excluding spaces)
    char_no_space = len(text.replace(' ', ''))
    
    # Count words
    words = text.split()
    word_count = len(words)
    
    # Count sentences (rough estimate)
    sentence_endings = text.count('.') + text.count('!') + text.count('?')
    
    # Count lines
    lines = text.split('\\n')
    line_count = len(lines)
    
    # Find most common words
    word_freq = {}
    for word in words:
        word_lower = word.lower().strip('.,!?;:')
        word_freq[word_lower] = word_freq.get(word_lower, 0) + 1
    
    most_common = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]
    
    # Display results
    print("\\n=== Text Analysis Results ===")
    print(f"Characters (with spaces): {char_count}")
    print(f"Characters (no spaces): {char_no_space}")
    print(f"Words: {word_count}")
    print(f"Lines: {line_count}")
    print(f"Sentences (approx): {sentence_endings}")
    
    if most_common:
        print("\\nMost common words:")
        for word, count in most_common:
            print(f"  {word}: {count}")

print("=== Word Counter ===")
print("Enter your text (type 'END' on a new line when done):\\n")

lines = []
while True:
    line = input()
    if line.strip() == 'END':
        break
    lines.append(line)

text = '\\n'.join(lines)

if text.strip():
    analyze_text(text)
else:
    print("No text entered!")
`
      }
    ]
  }
];
