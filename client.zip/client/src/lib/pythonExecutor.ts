/**
 * Python Executor using Pyodide
 * Runs Python code in the browser via WebAssembly
 */

declare global {
  interface Window {
    loadPyodide: any;
    pyodide: any;
  }
}

export class PythonExecutor {
  private static pyodideInstance: any = null;
  private static loading = false;
  private static loadPromise: Promise<any> | null = null;

  /**
   * Initialize Pyodide (lazy load)
   */
  static async initialize(): Promise<void> {
    if (this.pyodideInstance) {
      return;
    }

    if (this.loading) {
      await this.loadPromise;
      return;
    }

    this.loading = true;
    this.loadPromise = this.loadPyodide();
    await this.loadPromise;
    this.loading = false;
  }

  private static async loadPyodide(): Promise<void> {
    if (typeof window.loadPyodide === 'undefined') {
      throw new Error('Pyodide script not loaded. Make sure pyodide.js is included in index.html');
    }

    try {
      this.pyodideInstance = await window.loadPyodide({
        indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/'
      });
      console.log('Pyodide loaded successfully');
    } catch (error) {
      console.error('Failed to load Pyodide:', error);
      throw error;
    }
  }

  /**
   * Execute Python code
   */
  static async runPython(code: string, files?: Record<string, string>): Promise<{
    output: string;
    error?: string;
  }> {
    await this.initialize();

    try {
      // Redirect stdout to capture print statements
      await this.pyodideInstance.runPythonAsync(`
import sys
from io import StringIO
sys.stdout = StringIO()
sys.stderr = StringIO()
`);

      // If files are provided, write them to the virtual filesystem
      if (files) {
        for (const [filename, content] of Object.entries(files)) {
          await this.pyodideInstance.runPythonAsync(`
with open('${filename}', 'w') as f:
    f.write('''${content.replace(/'/g, "\\'")}''')
`);
        }
      }

      // Run the actual code
      await this.pyodideInstance.runPythonAsync(code);

      // Get output
      const stdout = await this.pyodideInstance.runPythonAsync('sys.stdout.getvalue()');
      const stderr = await this.pyodideInstance.runPythonAsync('sys.stderr.getvalue()');

      if (stderr) {
        return {
          output: stdout || '',
          error: stderr
        };
      }

      return {
        output: stdout || 'Code executed successfully (no output)'
      };
    } catch (error: any) {
      return {
        output: '',
        error: error.message || 'Unknown error occurred'
      };
    }
  }

  /**
   * Install Python packages
   */
  static async installPackage(packageName: string): Promise<void> {
    await this.initialize();
    await this.pyodideInstance.loadPackage(packageName);
  }

  /**
   * Generate HTML wrapper for Python code with Pyodide
   */
  static generateHTMLWrapper(pythonCode: string, title: string = 'Python App'): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <script src="https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js"></script>
  <style>
    body {
      margin: 0;
      padding: 20px;
      font-family: 'Courier New', monospace;
      background: #0f0f23;
      color: #00ff00;
    }
    #output {
      white-space: pre-wrap;
      font-family: monospace;
      background: #1a1a2e;
      padding: 20px;
      border-radius: 8px;
      border: 2px solid #9b87f5;
      min-height: 200px;
    }
    #loading {
      text-align: center;
      color: #9b87f5;
      padding: 40px;
    }
    .error {
      color: #ff4444;
    }
  </style>
</head>
<body>
  <div id="loading">Loading Python runtime...</div>
  <div id="output" style="display: none;"></div>

  <script type="text/javascript">
    async function main() {
      const loadingDiv = document.getElementById('loading');
      const outputDiv = document.getElementById('output');
      
      try {
        // Load Pyodide
        loadingDiv.textContent = 'Loading Python runtime...';
        const pyodide = await loadPyodide({
          indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/'
        });
        
        loadingDiv.style.display = 'none';
        outputDiv.style.display = 'block';
        
        // Redirect stdout
        await pyodide.runPythonAsync(\`
import sys
from io import StringIO
sys.stdout = StringIO()
sys.stderr = StringIO()
\`);
        
        // Run Python code
        const pythonCode = \`${pythonCode.replace(/`/g, '\\`').replace(/\$/g, '\\$')}\`;
        await pyodide.runPythonAsync(pythonCode);
        
        // Get output
        const stdout = await pyodide.runPythonAsync('sys.stdout.getvalue()');
        const stderr = await pyodide.runPythonAsync('sys.stderr.getvalue()');
        
        if (stderr) {
          outputDiv.innerHTML = '<span class="error">' + stderr + '</span>';
        } else {
          outputDiv.textContent = stdout || 'Program executed successfully (no output)';
        }
      } catch (error) {
        loadingDiv.style.display = 'none';
        outputDiv.style.display = 'block';
        outputDiv.innerHTML = '<span class="error">Error: ' + error.message + '</span>';
      }
    }
    
    main();
  </script>
</body>
</html>`;
  }
}
